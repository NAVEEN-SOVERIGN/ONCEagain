import requests
import time
from models import PatientAdmit

API = "http://localhost:8000/api/admit"
# 1. Neuro patient (High Risk)
requests.post(API, json={"patient_id": "SIM_NEURO_01", "name": "Alice Neuro", "age": 75, "weight_kg": 65, "height_cm": 160, "room": "N-100", "diagnosis": "Parkinsons", "assigned_nurse": "Nurse Jane", "parkinsons": True, "post_stroke": False, "on_opioids": False, "on_antipsychotics": False, "ward_type": "neuro", "muscle_issues": True, "vision_issues": False, "recent_surgery": "", "assigned_band": "BAND-1"})
# 2. General High Risk
requests.post(API, json={"patient_id": "SIM_GEN_02", "name": "Bob GenHigh", "age": 82, "weight_kg": 80, "height_cm": 175, "room": "G-200", "diagnosis": "Weakness", "assigned_nurse": "Nurse Jane", "parkinsons": False, "post_stroke": True, "on_opioids": True, "on_antipsychotics": False, "ward_type": "general", "muscle_issues": True, "vision_issues": True, "recent_surgery": "", "assigned_band": "BAND-2"})
# 3. General Low Risk
requests.post(API, json={"patient_id": "SIM_LOW_03", "name": "Charlie Low", "age": 45, "weight_kg": 70, "height_cm": 180, "room": "G-201", "diagnosis": "Observation", "assigned_nurse": "Nurse Jane", "parkinsons": False, "post_stroke": False, "on_opioids": False, "on_antipsychotics": False, "ward_type": "general", "muscle_issues": False, "vision_issues": False, "recent_surgery": "", "assigned_band": "BAND-3"})
print("Done")
