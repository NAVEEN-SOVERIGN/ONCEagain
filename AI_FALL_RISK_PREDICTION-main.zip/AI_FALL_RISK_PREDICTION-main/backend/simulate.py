import requests
import time

URL = "http://localhost:8000/api/band-data"

# 1. Send "Normal" walking data
print("Sending Normal Data...")
normal_data = {
    "patient_id": "PT-002",
    "accel_x": 0.5, "accel_y": 0.2, "accel_z": 9.8,
    "gyro_x": 0.1, "gyro_y": 0.0, "gyro_z": 0.1,
    "grav_x": 1.5, "grav_y": 9.8, "grav_z": -0.5, # Slightly leaning right
    "spo2": 98.0, "heart_rate": 72.0
}
requests.post(URL, json=normal_data)
time.sleep(3) # Wait 3 seconds

# 2. Send "Fall / Emergency" data
print("🚨 Simulating Sudden Fall & Oxygen Drop!")
fall_data = {
    "patient_id": "PT-002",
    "accel_x": 4.5, "accel_y": 1.0, "accel_z": 2.0, # High lateral acceleration
    "gyro_x": 1.5, "gyro_y": 2.0, "gyro_z": 0.5,
    "grav_x": 6.8, "grav_y": 0.0, "grav_z": 5.2, # Severe tilt Forward-Right!
    "spo2": 89.0, "heart_rate": 110.0 # Hypoxia / Panic heart rate
}
requests.post(URL, json=fall_data)
print("Data sent! Check your dashboard!")