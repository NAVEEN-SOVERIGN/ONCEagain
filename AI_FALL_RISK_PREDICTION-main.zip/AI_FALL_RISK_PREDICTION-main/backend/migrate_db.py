"""
Database Migration Script — ClinicalGuard
Adds missing columns to the existing patients.db without losing existing data.
Run once: python3 migrate_db.py
"""
import sqlite3

DB_PATH = "patients.db"

MIGRATIONS = [
    ("weight_kg",    "ALTER TABLE patients ADD COLUMN weight_kg REAL"),
    ("height_cm",    "ALTER TABLE patients ADD COLUMN height_cm REAL"),
    ("assigned_spo2","ALTER TABLE patients ADD COLUMN assigned_spo2 TEXT"),
]

def run():
    conn = sqlite3.connect(DB_PATH)
    cur  = conn.cursor()

    # Get existing columns
    cur.execute("PRAGMA table_info(patients)")
    existing = {row[1] for row in cur.fetchall()}
    print(f"Existing columns: {sorted(existing)}")

    added = []
    for col_name, sql in MIGRATIONS:
        if col_name not in existing:
            cur.execute(sql)
            added.append(col_name)
            print(f"  [+] Added column: {col_name}")
        else:
            print(f"  [=] Already exists: {col_name}")

    conn.commit()
    conn.close()

    if added:
        print(f"\nMigration complete — added {len(added)} column(s): {added}")
    else:
        print("\nDatabase already up-to-date. Nothing changed.")

if __name__ == "__main__":
    run()
