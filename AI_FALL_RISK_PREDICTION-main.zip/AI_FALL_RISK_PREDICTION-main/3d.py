import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D

def animate_sahay_fall():
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # 1. SETUP COORDINATES (Y-Downwards as requested)
    # X: Left/Right, Y: Up/Down (Inverted), Z: Forward/Back
    def setup_axes():
        ax.set_xlim(-1, 1)
        ax.set_ylim(1, -1)  # Inverting Y to make +Y point down
        ax.set_zlim(-1, 1)
        ax.set_xlabel('X (Lateral)')
        ax.set_ylabel('Y (Gravity/Down)')
        ax.set_zlabel('Z (Forward)')
        ax.set_title("SAHAY: Real-Time Fall Risk Animation", fontsize=14, pad=20)

    # 2. CREATE STATIC ELEMENTS (Safety Cone)
    # 20-degree safety threshold cone
    angle_limit = 20
    rad_limit = np.radians(angle_limit)
    h = 0.8
    r = h * np.tan(rad_limit)
    u_cone = np.linspace(0, 2 * np.pi, 30)
    v_cone = np.linspace(0, h, 10)
    U, V = np.meshgrid(u_cone, v_cone)
    X_c = (V/h) * r * np.cos(U)
    Z_c = (V/h) * r * np.sin(U)
    Y_c = -V # Cone points "upward" (negative Y)
    ax.plot_surface(X_c, Y_c, Z_c, color='g', alpha=0.1, lw=0)

    # 3. INITIALIZE ANIMATED ELEMENTS
    # Spine/Torso Line
    line, = ax.plot([], [], [], color='#2c3e50', lw=5, label='Patient Trunk')
    # Head
    head = ax.scatter([], [], [], color='#e67e22', s=200)
    # Risk Text
    risk_text = ax.text2D(0.05, 0.85, "", transform=ax.transAxes, fontsize=12, 
                         bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # Legend
    ax.legend(loc='upper right')

    def init():
        line.set_data([], [])
        line.set_3d_properties([])
        return line, head, risk_text

    def update(frame):
        # Simulate a forward fall (tilting on the Z-axis)
        # Frame goes from 0 to 45 degrees
        max_tilt = 45
        current_angle = (frame / 100) * max_tilt
        rad = np.radians(current_angle)
        
        # Calculate new coordinates for the head/top of torso
        # Pivot point is (0,0,0) - The Waist Band
        z_pos = np.sin(rad) * 0.9
        y_pos = -np.cos(rad) * 0.9
        x_pos = 0 

        # Update line (Spine)
        line.set_data([0, x_pos], [0, y_pos])
        line.set_3d_properties([0, z_pos])
        
        # Update head
        head._offsets3d = ([x_pos], [y_pos], [z_pos])

        # Logic for Risk Level
        risk_percent = min(100, int((current_angle / 20) * 50))
        status = "STABLE"
        t_color = "green"
        
        if current_angle > 20:
            status = "CRITICAL: FALL RISK"
            t_color = "red"
            line.set_color('red')
        else:
            line.set_color('#2c3e50')

        risk_text.set_text(f"Tilt Angle: {current_angle:.1f}°\n"
                          f"Risk Level: {risk_percent}%\n"
                          f"Status: {status}")
        risk_text.set_color(t_color)
        
        # Slowly rotate camera for better 3D effect
        ax.view_init(elev=20, azim=45 + frame/2)
        
        return line, head, risk_text

    # 4. RUN ANIMATION
    setup_axes()
    ani = FuncAnimation(fig, update, frames=200, init_func=init, blit=False, interval=50)
    plt.show()

if __name__ == "__main__":
    animate_sahay_fall()