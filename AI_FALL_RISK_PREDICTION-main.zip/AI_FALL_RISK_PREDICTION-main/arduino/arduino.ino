#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <Wire.h>
#include <Adafruit_BNO08x.h>
#include <ArduinoJson.h>

// --- LED PINS ---
#define RED_LED 2   // GPIO 2 (D4) - Used for "Not Admitted / Error"
#define GREEN_LED 0 // GPIO 0 (D3) - Used for "Active / Admitted"

// --- UPDATE THESE WITH YOUR DETAILS ---
const char* ssid = "Barkha";
const char* password = "123456yuio";

// Make sure this IP matches the computer running your Uvicorn server!
const char* serverName = "http://10.242.216.142:8000/api/band-data"; 
const String patientID = "PT-6B71"; // Must match the ID you type in the Nurse Dashboard
// --------------------------------------

// BNO085 Setup
#define BNO08X_RESET -1
Adafruit_BNO08x bno08x(BNO08X_RESET);
sh2_SensorValue_t sensorValue;

// Variables
float accel_x = 0, accel_y = 0, accel_z = 0;
float gyro_x = 0, gyro_y = 0, gyro_z = 0;
float grav_x = 0, grav_y = 0, grav_z = 0;

// Hardware Simulation (Since we don't have a physical MAX30102 hooked up yet)
float simulated_spo2 = 98.0;
float simulated_hr = 72.0;

unsigned long lastPost = 0;

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);
  
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  
  // Start with Red ON (Booting up)
  digitalWrite(RED_LED, HIGH);
  digitalWrite(GREEN_LED, LOW);

  Serial.println("\n--- Hybrid AI Fall Prediction Band ---");

  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    // Blink Red while connecting
    digitalWrite(RED_LED, !digitalRead(RED_LED)); 
  }
  Serial.println("\nWiFi Connected!");

  // Initialize BNO085
  if (!bno08x.begin_I2C()) {
    Serial.println("BNO085 not found! Check wiring.");
    while (1) { delay(10); } // Halt
  }
  Serial.println("BNO085 Found! Enabling sensors...");

  bno08x.enableReport(SH2_ACCELEROMETER, 20000); // 50Hz
  bno08x.enableReport(SH2_GYROSCOPE_CALIBRATED, 20000);
  bno08x.enableReport(SH2_GRAVITY, 20000);
  
  // Ready to connect to server.
  digitalWrite(RED_LED, HIGH); // Stay red until server says "Success"
}

void loop() {
  if (bno08x.wasReset()) {
    bno08x.enableReport(SH2_ACCELEROMETER, 20000);
    bno08x.enableReport(SH2_GYROSCOPE_CALIBRATED, 20000);
    bno08x.enableReport(SH2_GRAVITY, 20000); 
  }

  if (bno08x.getSensorEvent(&sensorValue)) {
    switch (sensorValue.sensorId) {
      case SH2_ACCELEROMETER:
        accel_x = sensorValue.un.accelerometer.x;
        accel_y = sensorValue.un.accelerometer.y;
        accel_z = sensorValue.un.accelerometer.z;
        break;
      case SH2_GYROSCOPE_CALIBRATED:
        gyro_x = sensorValue.un.gyroscope.x;
        gyro_y = sensorValue.un.gyroscope.y;
        gyro_z = sensorValue.un.gyroscope.z;
        break;
      case SH2_GRAVITY:
        grav_x = sensorValue.un.gravity.x;
        grav_y = sensorValue.un.gravity.y;
        grav_z = sensorValue.un.gravity.z;
        break;
    }
  }
  
  // Throttle HTTP POSTs: Allow sensor to buffer reading between sends
  if (millis() - lastPost > 150) {
    sendDataToAPI();
    lastPost = millis();
  }
  
  delay(10); 
}

void sendDataToAPI() {
  if (WiFi.status() == WL_CONNECTED) {
    WiFiClient client;
    HTTPClient http;

    http.begin(client, serverName);
    http.addHeader("Content-Type", "application/json");

    StaticJsonDocument<384> doc; 
    
    doc["patient_id"] = patientID;
    
    // Kinematic Data
    doc["accel_x"] = accel_x;
    doc["accel_y"] = accel_y;
    doc["accel_z"] = accel_z;
    doc["gyro_x"] = gyro_x;
    doc["gyro_y"] = gyro_y;
    doc["gyro_z"] = gyro_z;
    doc["grav_x"] = grav_x;
    doc["grav_y"] = grav_y;
    doc["grav_z"] = grav_z;

    // Simulated Vitals Data
    doc["spo2"] = simulated_spo2;
    doc["heart_rate"] = simulated_hr;

    String jsonPayload;
    serializeJson(doc, jsonPayload);

    int httpResponseCode = http.POST(jsonPayload);
    String responseBody = http.getString();

    if (httpResponseCode == 200) {
      // Check if the server accepted the data or threw the "Not Admitted" error
      if (responseBody.indexOf("error") > 0) {
        // Patient not admitted yet! Blink Red LED.
        digitalWrite(GREEN_LED, LOW);
        digitalWrite(RED_LED, !digitalRead(RED_LED)); 
        Serial.println("Server: Waiting for Nurse to admit patient...");
      } else {
        // Success! Turn on Green LED.
        digitalWrite(RED_LED, LOW);
        digitalWrite(GREEN_LED, HIGH);
        Serial.println("Server: Data accepted!");
      }
    } else {
      // Server offline or connection failed
      digitalWrite(GREEN_LED, LOW);
      digitalWrite(RED_LED, HIGH);
      Serial.print("HTTP Error code: ");
      Serial.println(httpResponseCode);
    }
    http.end();
  }
}
