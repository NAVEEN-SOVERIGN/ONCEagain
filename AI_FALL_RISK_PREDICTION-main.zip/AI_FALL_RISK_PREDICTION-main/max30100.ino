#include <Wire.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <ArduinoJson.h>
#include "MAX30100_PulseOximeter.h"

// ─── CONFIG ───────────────────────────────────────
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_URL    = "http://10.156.9.142:8000/api/sensor/vitals"; // update if PC IP changes
// ──────────────────────────────────────────────────

#define REPORTING_PERIOD_MS 5000  // send every 5 seconds

PulseOximeter pox;
uint32_t tsLastReport = 0;

void onBeatDetected() {
    Serial.println("♥ Beat!");
}

void connectWiFi() {
    Serial.print("Connecting to WiFi");
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println("\nWiFi connected! IP: " + WiFi.localIP().toString());
}

void sendData(float heartRate, uint8_t spO2) {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("WiFi disconnected. Reconnecting...");
        connectWiFi();
        return;
    }

    WiFiClient client;
    HTTPClient http;
    http.begin(client, SERVER_URL);
    http.addHeader("Content-Type", "application/json");

    // Build JSON payload
    StaticJsonDocument<128> doc;
    doc["heart_rate"] = heartRate;
    doc["spo2"]       = spO2;
    doc["device_id"]  = "esp8266_01";

    String payload;
    serializeJson(doc, payload);

    Serial.println("Sending: " + payload);

    int responseCode = http.POST(payload);

    if (responseCode > 0) {
        Serial.println("Server response: " + String(responseCode));
        Serial.println(http.getString());
    } else {
        Serial.println("POST failed: " + String(http.errorToString(responseCode)));
    }

    http.end();
}

void setup() {
    Serial.begin(115200);
    Wire.begin(4, 5); // SDA=D2, SCL=D1

    connectWiFi();

    Serial.println("Initializing MAX30100...");
    if (!pox.begin()) {
        Serial.println("FAILED: Check wiring & pull-up resistors!");
        for(;;);
    }

    pox.setIRLedCurrent(MAX30100_LED_CURR_7_6MA);
    pox.setOnBeatDetectedCallback(onBeatDetected);
    Serial.println("Ready! Place finger on sensor...");
}

void loop() {
    pox.update();

    if (millis() - tsLastReport > REPORTING_PERIOD_MS) {
        float heartRate = pox.getHeartRate();
        uint8_t spO2   = pox.getSpO2();

        Serial.printf("HR: %.1f bpm | SpO2: %d%%\n", heartRate, spO2);

        // Only send if readings are valid
        if (heartRate > 0 && spO2 > 0) {
            sendData(heartRate, spO2);
        } else {
            Serial.println("Invalid reading, skipping send...");
        }

        tsLastReport = millis();
    }
}